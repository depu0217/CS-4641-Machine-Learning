## **Author**

Name: Wenjun Wu

GT username: wwu94

## Project Info

Implmentation Platform: BURLAP java library: http://burlap.cs.brown.edu/. 

## Experiments

To run the code

1. Start a project in Eclipse with Java 1.7
2. Maven —> Update project should solve the error of linking library. 

FILE DESCRIPTION

/Users/wuwenjun/Documents/Gatech\ Academic/CS\ 4641/Assignment\ 4/New\ Code/src/main/java/assignment4

	GridWorldPI			%run GridWorld using Policy Iteration
	GridWorldVI			%run GridWorld using Value Iteration
	GridWorldQL			%Experiments with GridWorld with Q-Learning
	GridWorldQL2		%Single-run Q-Learning with GridWorld
	BlockDudePI			%run Block Dude using Policy Iteration
	BlockDudeVI			%run Block Dude using Value Iteration
	BlockDudeQL			%Experiments with Block Dude with Q-Learning
	GridWorldQL2		%Single-run Q-Learning with Block Dude
	*.java			%support java files

Supproting Files/
	results.xlsx							%All Numerical Results

wwu94-analysis.pdf						% report
​	
​		
​		
​		
​		
​		
​		
​		
​		
​		