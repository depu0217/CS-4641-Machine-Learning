package opt.test;
import shared.Instance;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
import java.util.Date;

import dist.DiscreteDependencyTree;
import dist.DiscretePermutationDistribution;
import dist.DiscreteUniformDistribution;
import dist.Distribution;
import opt.DiscreteChangeOneNeighbor;
import opt.EvaluationFunction;
import opt.GenericHillClimbingProblem;
import opt.HillClimbingProblem;
import opt.NeighborFunction;
import opt.RandomizedHillClimbing;
import opt.SimulatedAnnealing;
import opt.example.*;
import opt.ga.CrossoverFunction;
import opt.ga.DiscreteChangeOneMutation;
import opt.ga.GenericGeneticAlgorithmProblem;
import opt.ga.GeneticAlgorithmProblem;
import opt.ga.MutationFunction;
import opt.ga.StandardGeneticAlgorithm;
import opt.ga.UniformCrossOver;
import opt.prob.GenericProbabilisticOptimizationProblem;
import opt.prob.MIMIC;
import opt.prob.ProbabilisticOptimizationProblem;
import shared.FixedIterationTrainer;

/**
 * 
 * author Andrew Guillory gtg008g@mail.gatech.edu
 * @version 1.0
 */
public class RasTest {
	
    /** The n value */
	// generate values between 0 and 2
    private static final int N = 2;
    private static int iterations;

    public static void main(String[] args) {
    	Scanner reader = new Scanner(System.in);
    	System.out.println("Enter the number of iterations");
        iterations = reader.nextInt();
        double temp = 0.6;
        
        
        RasFunction ef = new RasFunction();
        // 32 bit precision * 2 variables :)
        int[] ranges = new int[64];
        
        
        Arrays.fill(ranges, N);
        Distribution odd = new  DiscreteUniformDistribution(ranges);
        Distribution df = new DiscreteDependencyTree(.1, ranges); 
        ProbabilisticOptimizationProblem pop = new GenericProbabilisticOptimizationProblem(ef, odd, df);
        
        NeighborFunction nf = new DiscreteChangeOneNeighbor(ranges);
        MutationFunction mf = new DiscreteChangeOneMutation(ranges);
        CrossoverFunction cf = new UniformCrossOver();
        HillClimbingProblem hcp = new GenericHillClimbingProblem(ef, odd, nf);
        GeneticAlgorithmProblem gap = new GenericGeneticAlgorithmProblem(ef, odd, mf, cf);
        
        double start, trainingTime, end = 0;
        RandomizedHillClimbing rhc = new RandomizedHillClimbing(hcp);      
        FixedIterationTrainer fit = new FixedIterationTrainer(rhc, iterations);
        start = System.nanoTime();
        fit.train();
        end = System.nanoTime();
        trainingTime = end - start;
        trainingTime /= Math.pow(10,9);
        System.out.println("RHC: " + -ef.value(rhc.getOptimal()) + " Time: " + trainingTime);
        
        SimulatedAnnealing sa = new SimulatedAnnealing(100, temp, hcp);
        fit = new FixedIterationTrainer(sa, iterations);
        start = System.nanoTime();
        fit.train();
        end = System.nanoTime();
        trainingTime = end - start;
        trainingTime /= Math.pow(10,9);
        System.out.println("SA: " + -ef.value(sa.getOptimal()) + " Time: " + trainingTime);
        
        StandardGeneticAlgorithm ga = new StandardGeneticAlgorithm(200, 150, 25, gap);
        fit = new FixedIterationTrainer(ga, iterations);
        start = System.nanoTime();
        fit.train();
        end = System.nanoTime();
        trainingTime = end - start;
        trainingTime /= Math.pow(10,9);
        System.out.println("GA: " + -ef.value(ga.getOptimal()) + " Time: " + trainingTime);
        
        
        
        MIMIC mimic = new MIMIC(200, 100, pop);
        fit = new FixedIterationTrainer(mimic, iterations);
        start = System.nanoTime();
        fit.train();
        end = System.nanoTime();
        trainingTime = end - start;
        trainingTime /= Math.pow(10,9);
        Instance d = mimic.getOptimal ();
    	double[] xy = new double[2];
    	ef.convertInstance (d,xy);
    	double x = xy[0];
    	double y = xy[1];
    	
    	System.out.println ("MIMIC: " + -ef.value(d) + " " + " Time " +  trainingTime);  
    	
        //System.out.println("elapsed time " + trainingTime + " seconds");
        
    }
}
